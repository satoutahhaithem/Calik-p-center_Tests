This is a distribution of randomly-generated, realistic instances of the
ramp-constrained, hydro-thermal Unit Commitment problem. The distribution
comes with the following files:

- Format.pdf: a document describing the format of the instances, as well as
  giving references to articles where they are used and described;

- T-Ramp: a directory containing pure thermal (i.e., without hydro units)
  instances.

- HT-Ramp: a directory containing hydro-thermal instances.

Each instance is named according to the scheme

     T-H-N.mod

where T is the number of thermal units (between 10 and 200), H is the number
of hydro units (between 10 and 100), and N is an integer (between 1 and 5 for
pure thermal instances, between 1 and 2 for hydro-thermal ones) distinguishing
different instances of the same size between them. Pure thermal instances all
have H = 0.
